## Overview

Template files used to create new documents and documents with sample content in: 

* [Confluence ONLYOFFICE integration plugin](https://github.com/ONLYOFFICE/onlyoffice-confluence)
* [HumHub ONLYOFFICE integration plugin](https://github.com/ONLYOFFICE/onlyoffice-humhub)
* [Liferay ONLYOFFICE Connector](https://github.com/ONLYOFFICE/onlyoffice-liferay)
* [Nextcloud ONLYOFFICE integration app](https://github.com/ONLYOFFICE/onlyoffice-nextcloud)
* [ONLYOFFICE Alfresco module package](https://github.com/ONLYOFFICE/onlyoffice-alfresco)
* [ownCloud ONLYOFFICE integration app](https://github.com/onlyoffice/onlyoffice-owncloud)
