---
date: "2016-12-01T16:00:00+02:00"
title: "Advanced"
slug: "advanced"
weight: 30
toc: false
draft: false
menu:
  sidebar:
    name: "Advanced"
    weight: 40
    identifier: "advanced"
---
