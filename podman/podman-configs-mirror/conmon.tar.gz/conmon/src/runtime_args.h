#if !defined(RUNTIME_ARGS_H)
#define RUNTIME_ARGS_H

#include <glib.h>

GPtrArray *configure_runtime_args(const char *const csname);

#endif // RUNTIME_ARGS_H
