#if !defined(OOM_H)
#define OOM_H

void attempt_oom_adjust(const char *const oom_score);

#endif // OOM_H
